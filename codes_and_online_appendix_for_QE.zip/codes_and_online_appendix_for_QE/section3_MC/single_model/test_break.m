x=2;

for kk=1:1
if x==2
    
    break;
end
disp('test')

end